# vaultic
vaultic is a terminal tool made in python, that is a password manager that stores your passwords in randomly fetched memes!

